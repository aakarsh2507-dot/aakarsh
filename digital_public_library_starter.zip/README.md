# Digital Public Library

A starter Flask application for a small digital library. It includes a book catalogue, search, member registration, book issuing and returns, and a SQLite database.

> This is a newly created starter implementation based on the feature outline discussed in ChatGPT. It is **not** the original source code of the referenced live website and does not copy its exact design or data.

## Features

- Browse and search books by title or author
- Add books and copy counts
- Register members
- Issue available books to registered members
- Record book returns
- Dashboard counts for titles, available copies, issued books, and members

## Run locally

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
flask --app app init-db
flask --app app seed-demo
python app.py
```

Open http://127.0.0.1:5000

## Deploy

### Render (simple option)

1. Push this project to your GitHub repository.
2. Create a new **Web Service** on Render and connect the repository.
3. Set **Build Command** to `pip install -r requirements.txt`.
4. Set **Start Command** to `gunicorn app:app`.
5. Add environment variable `SECRET_KEY` with a long random value.
6. For persistent data, configure a persistent disk and set `DATABASE_URL` appropriately, or use a managed PostgreSQL database.

### PythonAnywhere

1. Upload/clone the project into your PythonAnywhere account.
2. Create a Flask web app using the manual configuration option.
3. Configure the WSGI file to import `app` from this project.
4. Install dependencies in the web app's virtual environment.
5. Ensure the database directory is writable.

## Important before public use

This is a learning/demo starter, not a production-ready library system. It currently has no authentication or role-based permissions, so do not expose the add/issue/return actions publicly without adding login and authorization. Use a production secret key and a persistent database for deployment.
