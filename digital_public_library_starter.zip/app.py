from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import os

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "change-this-before-deploying")
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get(
    "DATABASE_URL", "sqlite:///" + os.path.join(app.instance_path, "library.db")
)
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

os.makedirs(app.instance_path, exist_ok=True)
db = SQLAlchemy(app)


class Book(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(160), nullable=False)
    author = db.Column(db.String(120), nullable=False, default="Unknown")
    total_copies = db.Column(db.Integer, nullable=False, default=1)
    available_copies = db.Column(db.Integer, nullable=False, default=1)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Member(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(160), unique=True, nullable=False)


class Issue(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    book_id = db.Column(db.Integer, db.ForeignKey("book.id"), nullable=False)
    member_id = db.Column(db.Integer, db.ForeignKey("member.id"), nullable=False)
    issued_at = db.Column(db.DateTime, default=datetime.utcnow)
    returned_at = db.Column(db.DateTime)
    book = db.relationship("Book", backref="issues")
    member = db.relationship("Member", backref="issues")


@app.route("/")
def index():
    search = request.args.get("q", "").strip()
    query = Book.query
    if search:
        query = query.filter(
            db.or_(Book.title.ilike(f"%{search}%"), Book.author.ilike(f"%{search}%"))
        )
    books = query.order_by(Book.title.asc()).all()
    stats = {
        "titles": Book.query.count(),
        "copies": db.session.query(db.func.sum(Book.available_copies)).scalar() or 0,
        "issued": Issue.query.filter_by(returned_at=None).count(),
        "members": Member.query.count(),
    }
    return render_template("index.html", books=books, stats=stats, search=search)


@app.route("/add-book", methods=["GET", "POST"])
def add_book():
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        author = request.form.get("author", "").strip() or "Unknown"
        copies = request.form.get("copies", "1")
        if not title:
            flash("Please enter a book title.", "error")
            return redirect(url_for("add_book"))
        try:
            copies = max(1, int(copies))
        except ValueError:
            copies = 1
        db.session.add(Book(title=title, author=author, total_copies=copies, available_copies=copies))
        db.session.commit()
        flash("Book added successfully.", "success")
        return redirect(url_for("index"))
    return render_template("add_book.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        if not name or not email:
            flash("Name and email are required.", "error")
        elif Member.query.filter_by(email=email).first():
            flash("That email is already registered.", "error")
        else:
            db.session.add(Member(name=name, email=email))
            db.session.commit()
            flash("Registration successful.", "success")
            return redirect(url_for("index"))
    return render_template("register.html")


@app.route("/issue/<int:book_id>", methods=["POST"])
def issue_book(book_id):
    book = Book.query.get_or_404(book_id)
    member_id = request.form.get("member_id", type=int)
    member = db.session.get(Member, member_id) if member_id else None
    if not member:
        flash("Register a member before issuing a book.", "error")
    elif book.available_copies < 1:
        flash("No copies of this book are currently available.", "error")
    else:
        book.available_copies -= 1
        db.session.add(Issue(book=book, member=member))
        db.session.commit()
        flash(f'"{book.title}" issued to {member.name}.', "success")
    return redirect(url_for("index"))


@app.route("/return/<int:issue_id>", methods=["POST"])
def return_book(issue_id):
    issue = Issue.query.get_or_404(issue_id)
    if issue.returned_at is None:
        issue.returned_at = datetime.utcnow()
        issue.book.available_copies += 1
        db.session.commit()
        flash("Book returned successfully.", "success")
    return redirect(url_for("index"))


@app.cli.command("init-db")
def init_db():
    """Create database tables."""
    db.create_all()
    print("Database tables created.")


@app.cli.command("seed-demo")
def seed_demo():
    """Add a few sample books and members to an empty database."""
    db.create_all()
    if Book.query.count() == 0:
        db.session.add_all([
            Book(title="Wings of Fire", author="A. P. J. Abdul Kalam", total_copies=4, available_copies=4),
            Book(title="The Alchemist", author="Paulo Coelho", total_copies=3, available_copies=3),
            Book(title="The Guide", author="R. K. Narayan", total_copies=2, available_copies=2),
        ])
    if Member.query.count() == 0:
        db.session.add(Member(name="Demo Student", email="demo@example.com"))
    db.session.commit()
    print("Demo data added.")


if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True)
